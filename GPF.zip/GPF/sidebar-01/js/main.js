const fullHeight = () => {
  $(".js-fullheight").css("height", $(window).height());
  $(window).resize(() => {
    $(".js-fullheight").css("height", $(window).height());
  });
};
fullHeight();

$("#sidebarCollapse").on("click", () => {
  $("#sidebar").toggleClass("active");
});
